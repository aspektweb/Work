document.getElementById('salomBtn').addEventListener('click', function() {
    alert("Assalomu alaykum, siz muvaffaqiyatga erishyapsiz!");
});